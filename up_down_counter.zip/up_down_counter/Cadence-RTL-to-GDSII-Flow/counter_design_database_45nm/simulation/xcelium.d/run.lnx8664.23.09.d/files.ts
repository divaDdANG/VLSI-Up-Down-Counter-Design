1761876774 /home/qhdnb4/cds.lib
1761598563 /home/qhdnb4/hdl.var
1765093895 /home/qhdnb4/pd_assignment1_2025/Cadence-RTL-to-GDSII-Flow/counter_design_database_45nm/simulation/up_down_counter.v
1765094022 /home/qhdnb4/pd_assignment1_2025/Cadence-RTL-to-GDSII-Flow/counter_design_database_45nm/simulation/testbench.v
